package tests.ios.login.tc;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.testng.Assert;
import org.testng.annotations.Test;
import tests.ios.login.po.BOLogin;
import core.constants.Keyword;

public class Login extends BOLogin{




    @Test
    public void tc_1_LoginWithUserIncorrectPassword() throws InterruptedException {
        ExtentTest test = extent.createTest("tc_1_LoginWithUserIncorrectPassword" , "Login With User Incorrect Password");
        test.log(Status.INFO, "Test tc_1_LoginWithUserIncorrectPassword started");
        BOLogin bOLogin = new BOLogin();
        bOLogin.loginWithUserWrongPassword();
    }

    @Test
    public void tc_2_ValidateMessageLoginFailed() throws InterruptedException {
        ExtentTest test = extent.createTest("tc_2_ValidateMessageLoginFailed" , "Validate Message Login Failed");
        test.log(Status.INFO, "Test tc_2_ValidateMessageLoginFailed started");
        BOLogin bOLogin = new BOLogin();
        bOLogin.validateLoginFailedMessage();
        Thread.sleep(5000);
        Assert.assertEquals(bOLogin.incorrectLoginMessageEl.getText(), Keyword.CustomKeyword.FAILLOGINMESSAGE.value );
        bOLogin.closeEl.click();

    }

//    @Test
//    public void tc_3_LoginWithNoCredential() throws InterruptedException {
//        ExtentTest test = extent.createTest("tc_3_LoginWithNoCredential" , "Login With No Credential");
//        test.log(Status.INFO, "Test tc_3_LoginWithNoCredential started");
//        BOLogin bOLogin = new BOLogin();
//        bOLogin.loginWithNoCredential();
//    }
//
//    @Test
//    public void tc_4_LoginWithValidUsernameWithoutPassword() throws InterruptedException {
//        ExtentTest test = extent.createTest("tc_4_LoginWithValidUsernameWithoutPassword" , "Login With Valid Username With out Password");
//        test.log(Status.INFO, "Test tc_4_LoginWithValidUsernameWithoutPassword started");
//        BOLogin bOLogin = new BOLogin();
//        bOLogin.loginWithValidUserWithoutPassword();
//    }
//
//    @Test
//    public void tc_5_LoginSuccessful() throws InterruptedException {
//        ExtentTest test = extent.createTest("tc_5_LoginSuccessful" , "Login Successful");
//        test.log(Status.INFO, "Test tc_5_LoginSuccessful started");
//        BOLogin bOLogin = new BOLogin();
//        bOLogin.loginSuccessful();
//    }


}
