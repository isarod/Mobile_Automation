package tests.ios.login.po;

import core.managers.AppDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import tests.ios.login.ExtentReportsDemo;


public class BOLogin extends ExtentReportsDemo {


    // initial driver Appium
    public BOLogin(){
        PageFactory.initElements(new AppiumFieldDecorator(AppDriver.getDriver()), this);
        return;
    }

    // define element

    @FindBy(id = "")
    public WebElement accept;


    @FindBy(xpath = "//XCUIElementTypeApplication[@name='Mi Claro - Local']/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeSecureTextField")
    public WebElement passwordEl;


    @FindBy(xpath = "//XCUIElementTypeApplication[@name='Mi Claro - Local']/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[2]/XCUIElementTypeOther/XCUIElementTypeTextField")
    public WebElement userEl;


    @FindBy(xpath = "//XCUIElementTypeStaticText[@name='Iniciar sesión']")
    public WebElement signEl;


    @FindBy(xpath = "//XCUIElementTypeButton[@name='Cerrar']")
    public WebElement closeEl;


    @FindBy(xpath = "//XCUIElementTypeStaticText[@name='El usuario y/o la contraseña son incorrectos']")
    public WebElement incorrectLoginMessageEl;


    private String loginUser = "qaTest";
    private String loginUserCorrect = "qas1";
    private String passWord = "12345678";
    private String wrongUser = "wrongUser";
    private String wrongPass = "wrongPass" ;



    public void loginWithUserWrongPassword() throws InterruptedException {
        Thread.sleep(500);
        userEl.clear();
        userEl.sendKeys(loginUser);
        passwordEl.sendKeys(wrongPass);
        signEl.click();
        Thread.sleep(300);
        closeEl.click();
        Thread.sleep(5000);

    }

    public void validateLoginFailedMessage() throws InterruptedException  {
        Thread.sleep(600);
        userEl.clear();
        userEl.sendKeys(wrongUser);
        passwordEl.sendKeys(wrongPass);
        signEl.click();
        // implementar validacion de msj
//        Thread.sleep(5000);
//        closeEl.click();
    }
    public void loginWithNoCredential() throws InterruptedException {
        Thread.sleep(500);
        userEl.clear();
        Thread.sleep(5000);
        signEl.click();
        Thread.sleep(5000);
        closeEl.click();
    }
    public void loginWithValidUserWithoutPassword() throws InterruptedException {
        Thread.sleep(500);
        userEl.clear();
        userEl.sendKeys(loginUser);
        signEl.click();
        Thread.sleep(5000);
        closeEl.click();
        Thread.sleep(5000);
    }

    public void loginSuccessful() throws InterruptedException {
        Thread.sleep(500);
        userEl.clear();
        userEl.sendKeys(loginUserCorrect);
        passwordEl.sendKeys(passWord);
        Thread.sleep(500);
        signEl.click();
        Thread.sleep(10000);

    }

}
