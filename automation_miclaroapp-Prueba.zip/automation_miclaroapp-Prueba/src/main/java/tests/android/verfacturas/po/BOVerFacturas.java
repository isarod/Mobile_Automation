package tests.android.verfacturas.po;

import core.managers.AppDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class BOVerFacturas {
    AppiumDriver driver;
    public Object UiSelector;
    public BOVerFacturas() {
        PageFactory.initElements(new AppiumFieldDecorator(AppDriver.getDriver()), this);
    }

        @AndroidFindBy(id = "com.clarord.miclaro.debug:id/next_tip")
        public static WebElement next_tip;

        @AndroidFindBy(id = "com.clarord.miclaro.debug:id/close_tips")
        public static WebElement close_tips;

        @AndroidFindBy(id = "com.clarord.miclaro.debug:id/username_view")
        public static WebElement username_view;

        @AndroidFindBy(id = "com.clarord.miclaro.debug:id/password_view")
        public static WebElement password_view;

        @AndroidFindBy(id = "com.clarord.miclaro.debug:id/full_login_button")
        public WebElement iniciarsesion;

        @AndroidFindBy(id = "com.clarord.miclaro.debug:id/back_icon")
        public WebElement back_icon;

        @AndroidFindBy(id = "com.clarord.miclaro.debug:id/container_view")
        public WebElement containerview;

        @AndroidFindBy(xpath = "//android.widget.TextView[@text='(829) 638-6021']")
        public WebElement movilControl;

        @AndroidFindBy(xpath = "//android.widget.TextView[@text='(809) 399-5833']")
        public WebElement smartPostpago;

        @AndroidFindBy(xpath = "//android.widget.TextView[@text='(829) 124-3801']")
        public WebElement internetMovilSolodatos;

        @AndroidFindBy(xpath = "//android.widget.TextView[@text='(829) 110-9739']")
        public WebElement internetMovilcontrol;

        @AndroidFindBy(xpath = "//android.widget.Button[@text='DESCARGAR']")
        public WebElement descargar;

        @AndroidFindBy(xpath = "//android.widget.ImageButton[@content-desc=\"Navigate up\"]")
        public WebElement navigateUp;

        public void viewFactMovilControl() throws InterruptedException {
        next_tip.click();
        close_tips.click();
        username_view.sendKeys("qas1");
        password_view.sendKeys("123456789");
        iniciarsesion.click();
        Thread.sleep(10000);
        movilControl.click();
        Thread.sleep(10000);
        descargar.click();
        Thread.sleep(6000);
        containerview.click();
        Thread.sleep(8000);
        navigateUp.click();
        Thread.sleep(500);
        back_icon.click();
        Thread.sleep(500);
        back_icon.click();
        Thread.sleep(500);
    }

      /*  public void viewFactSmartPostpago() throws InterruptedException {
        next_tip.click();
        close_tips.click();
        username_view.sendKeys("qas1");
        password_view.sendKeys("123456789");
        iniciarsesion.click();
        Thread.sleep(10000);
        smartPostpago.click();
        Thread.sleep(10000);
        descargar.click();
        Thread.sleep(6000);
        containerview.click();
        Thread.sleep(8000);
        navigateUp.click();
        Thread.sleep(500);
        back_icon.click();
        Thread.sleep(500);
        back_icon.click();
        Thread.sleep(500);
    }*/

        public void viewFactInternetMovilSoloDatos() throws InterruptedException {
        next_tip.click();
        close_tips.click();
        username_view.sendKeys("qas1");
        password_view.sendKeys("123456789");
        iniciarsesion.click();
        Thread.sleep(10000);
        internetMovilSolodatos.click();
        Thread.sleep(10000);
        descargar.click();
        Thread.sleep(6000);
        containerview.click();
        Thread.sleep(8000);
        navigateUp.click();
        Thread.sleep(500);
        back_icon.click();
        Thread.sleep(500);
        back_icon.click();
        Thread.sleep(500);
    }

       /* public void viewFactInternetMovilControl() throws InterruptedException {
        next_tip.click();
        close_tips.click();
        username_view.sendKeys("test9");
        password_view.sendKeys("123456789");
        iniciarsesion.click();
        Thread.sleep(10000);
        internetMovilcontrol.click();
        Thread.sleep(10000);
        descargar.click();
        Thread.sleep(6000);
        containerview.click();
        Thread.sleep(8000);
        navigateUp.click();
        Thread.sleep(500);
        back_icon.click();
        Thread.sleep(500);
        back_icon.click();
        Thread.sleep(500);
    }*/
}