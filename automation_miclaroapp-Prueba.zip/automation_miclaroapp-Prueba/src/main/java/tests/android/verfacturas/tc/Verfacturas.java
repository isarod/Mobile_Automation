package tests.android.verfacturas.tc;

import core.managers.AppFactory;
import org.testng.annotations.Test;
import tests.android.verfacturas.po.BOVerFacturas;

public class Verfacturas extends AppFactory {

    @Test
    public void tc_01_verfact_movilcontrol() throws InterruptedException {
        BOVerFacturas BOVerFacturas = new BOVerFacturas();
        BOVerFacturas.viewFactMovilControl();
    }

    @Test
    public void tc_02_verfact_smartpostPago() throws InterruptedException {
        BOVerFacturas BOVerFacturas = new BOVerFacturas();
        //BOVerFacturas.viewFactSmartPostpago();
    }

    @Test
    public void tc_03_verfact_internetmovilsolodatos() throws InterruptedException {
        BOVerFacturas BOVerFacturas = new BOVerFacturas();
        BOVerFacturas.viewFactInternetMovilSoloDatos();
    }

    @Test
    public void tc_04_verfact_internetmovilcontrol() throws InterruptedException {
        BOVerFacturas BOVerFacturas = new BOVerFacturas();
        //BOVerFacturas.viewFactInternetMovilControl();
    }

}
