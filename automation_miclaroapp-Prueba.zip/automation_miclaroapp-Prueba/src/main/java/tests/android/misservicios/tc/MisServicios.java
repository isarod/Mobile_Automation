package tests.android.misservicios.tc;

import core.managers.AppFactory;
import org.testng.annotations.Test;
import tests.android.misservicios.po.BOMisServicios;

public class MisServicios extends AppFactory{

   @Test
    public void tc_01_consultarmisservicios() throws InterruptedException {
        BOMisServicios BOMisServicios = new BOMisServicios();
        BOMisServicios.viewMisServicioslistado();
    }

   @Test
    public void tc_02_eliminarunserviciozafacon() throws InterruptedException {
        BOMisServicios BOMisServicios = new BOMisServicios();
        BOMisServicios.eliminarUnServicioCancelarAceptar();
    }

   @Test
    public void tc_03_agregarunservicio() throws InterruptedException {
        BOMisServicios BOMisServicios = new BOMisServicios();
        BOMisServicios.agregarUnServicio();
    }

}