package tests.android.misservicios.po;

import core.managers.AppDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class BOMisServicios{
    AppiumDriver driver;
    public Object UiSelector;

    public BOMisServicios() {
        PageFactory.initElements(new AppiumFieldDecorator(AppDriver.getDriver()), this);
    }

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/next_tip")
    public static WebElement next_tip;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/close_tips")
    public static WebElement close_tips;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/username_view")
    public static WebElement username_view;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/password_view")
    public static WebElement password_view;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/sim_card_digits")
    public static WebElement simcardigits;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/full_login_button")
    public WebElement iniciarsesion;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/design_navigation_view")
    public WebElement mainmenu;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/main_container")
    public WebElement inicio;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/back_icon")
    public WebElement back_icon;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/drawer_layout")
    public WebElement main_menu;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/action_add_subscription")
    public static WebElement agregar_servicio;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/action_delete_subscriptions")
    public static WebElement eliminar_servicio;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/multiple_selection_view")
    public static WebElement checkvarius;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/multiple_selection_view")
    public WebElement check;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='(829) 962-4677']")
    public WebElement movilprepago;

    @AndroidFindBy(xpath = "//android.widget.ImageButton[@text=\"Navigate up\"]")
    public WebElement navigateUp;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/delete_services_button")
    public WebElement eliminar;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/delete_services_button")
    public WebElement eliminar1;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='CANCELAR']")
    public WebElement cancelar;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='ACEPTAR']")
    public WebElement aceptar;

    @AndroidFindBy(xpath = "//android.widget.Button[@text='CERRAR']")
    public WebElement cerrar;

    @AndroidFindBy(id = "android.widget.FrameLayout")
    public WebElement popup;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/logout_menu_option")
    public WebElement logout;

    @AndroidFindBy(className = "//android.widget.CheckedTextView[@text=\"Salir\"]")
    public WebElement salir;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/continue_button")
    public WebElement continuar;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/validation_key_view")
    public WebElement smstoken;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/resend_token_button")
    public WebElement reenviarsmstoken;

    @AndroidFindBy(xpath = "//android.widget.ImageButton")
    public WebElement up;

    @AndroidFindBy(id = "com.clarord.miclaro.debug:id/continue_button")
    public WebElement confirmar;

    @AndroidFindBy(xpath = "//android.widget.ImageButton[@content-desc=\"Mi Claro\"]")
    public WebElement backtomain;

    @AndroidFindBy(xpath = "//android.widget.ImageButton[@content-desc='Mi Claro - Debug']")
    public WebElement mainMenuEl;

    @AndroidFindBy(xpath = "androidx.recyclerview.widget.RecyclerView")
    public static WebElement maindrawer;

    @AndroidFindBy(xpath = "//android.widget.ImageButton[@content-desc=\"Mi Claro - Debug\"]")
    public WebElement miclarodebug;

    public void viewMisServicioslistado() throws InterruptedException {
        next_tip.click();
        close_tips.click();
        username_view.sendKeys("qas1");
        password_view.sendKeys("123456789");
        iniciarsesion.click();
        Thread.sleep(8000);
        miclarodebug.click();
        Thread.sleep(800);
        logout.click();
        Thread.sleep(1000);

    }

    public void eliminarUnServicioCancelarAceptar() throws InterruptedException {
        next_tip.click();
        close_tips.click();
        username_view.sendKeys("qas1");
        password_view.sendKeys("123456789");
        iniciarsesion.click();
        Thread.sleep(8000);
        eliminar_servicio.click();
        Thread.sleep(800);
        movilprepago.click();
        Thread.sleep(300);
        eliminar1.click();
        Thread.sleep(5000);
        cancelar.click();
        Thread.sleep(2000);
        up.click();
        Thread.sleep(2000);
        eliminar_servicio.click();
        Thread.sleep(2000);
        movilprepago.click();
        Thread.sleep(300);
        eliminar1.click();
        Thread.sleep(5000);
        aceptar.click();
        Thread.sleep(2000);
        miclarodebug.click();
        Thread.sleep(2000);
        logout.click();
        Thread.sleep(2000);

    }

    public void agregarUnServicio() throws InterruptedException {
        next_tip.click();
        close_tips.click();
        username_view.sendKeys("qas1");
        password_view.sendKeys("123456789");
        iniciarsesion.click();
        Thread.sleep(9000);
        agregar_servicio.click();
        Thread.sleep(2000);
        movilprepago.click();
        Thread.sleep(800);
        continuar.click();
        Thread.sleep(2000);
        smstoken.click();
        Thread.sleep(11000);
        confirmar.click();
        Thread.sleep(2000);
        cerrar.click();
        Thread.sleep(2000);
        miclarodebug.click();
        Thread.sleep(1000);
        logout.click();
        Thread.sleep(2000);

    }

}