package tests.android.login.tc;

import org.testng.annotations.Test;
import tests.android.login.po.BOLogin;

public class Login {


    @Test
    public void tc_1_LoginConUsuarioContrasenaIncorrecta() throws InterruptedException {
        BOLogin BOLogin = new BOLogin();
        BOLogin.loginWithUserWrongPassword();
    }

    @Test
    public void tc_2_ValidarMensajeLoginFallido() throws InterruptedException {
        BOLogin BOLogin = new BOLogin();
        BOLogin.validateLoginFailedMessage();
    }

    @Test
    public void tc_3_LoginConNingunaCredencial() throws InterruptedException {
        BOLogin BOLogin = new BOLogin();
        BOLogin.loginWithNoCredential();
    }

    @Test
    public void tc_4_LoginConUsuarioValidoSinContrasena() throws InterruptedException {
        BOLogin BOLogin = new BOLogin();
        BOLogin.loginWithValidUserWithoutPassword();
    }

    @Test
    public void tc_5_login_Exitoso() throws InterruptedException {
        BOLogin BOLogin = new BOLogin();
        BOLogin.login_user();
    }



}
