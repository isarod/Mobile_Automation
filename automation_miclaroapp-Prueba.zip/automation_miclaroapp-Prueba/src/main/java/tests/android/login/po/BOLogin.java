package tests.android.login.po;

import core.managers.AppDriver;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class BOLogin {

    AppiumDriver driver;

    public BOLogin(){
        PageFactory.initElements(new AppiumFieldDecorator(AppDriver.getDriver()), this);
    }

    @FindBy(id = "com.clarord.miclaro.debug:id/next_tip")
    public WebElement nextArrow;

    @FindBy(id = "com.clarord.miclaro.debug:id/close_tips")
    public WebElement closeTips;

    @FindBy(id = "com.clarord.miclaro.debug:id/username_view")
    public WebElement userName;

    @FindBy(id = "com.clarord.miclaro.debug:id/password_view")
    public WebElement password;

    @FindBy(id = "com.clarord.miclaro.debug:id/full_login_button")
    public WebElement loginbutton;

    @FindBy(id = "android:id/button1")
    public WebElement accept;

//    MobileElement message = (MobileElement) driver.findElementByAccessibilityId("android:id/message");
//
//    String actualMessage = message.getAttribute("Text");
//    String expectMessage = "En estos momentos no es posible acceder al servicio. Por favor, inténtalo más tarde.";


    public void login_user() throws InterruptedException {
        Thread.sleep(800);
        userName.sendKeys("qas1");
        password.sendKeys("12345678");
        loginbutton.click();
        Thread.sleep(8000);
    }
    public void loginWithUserWrongPassword() throws InterruptedException {
        Thread.sleep(500);
        userName.sendKeys("qas1");
        password.sendKeys("wrongPassW");
        loginbutton.click();
        Thread.sleep(5000);
        accept.click();
        Thread.sleep(5000);
    }

    public void validateLoginFailedMessage() throws InterruptedException {
       //Thread.sleep(600);
        userName.sendKeys("wrongUser");
        password.sendKeys("wrongPass");
        //validate msj "Aun sin implementar"
        loginbutton.click();
        Thread.sleep(8000);
        accept.click();
    }
    public void loginWithNoCredential() throws InterruptedException {
        Thread.sleep(5000);
        loginbutton.click();
        Thread.sleep(5000);
        accept.click();
    }
    public void loginWithValidUserWithoutPassword() throws InterruptedException {
        userName.sendKeys("qas1");
        loginbutton.click();
        Thread.sleep(5000);
        accept.click();
        Thread.sleep(5000);

    }







}
