package tests.android.login.po;


import core.managers.AppDriver;
import core.managers.Util;
import org.openqa.selenium.By;

public class PoLogin {

    By contactTab = By.id("com.google.android.dialer:id/contacts_tab");

    By Add = By.xpath("//android.widget.TextView[@text='Create new contact']");

    By firstName = By.xpath("//android.widget.EditText[@text='First name']");

    By newContactScreen = By.xpath("//android.widget.TextView[@text='Create new contact']");

    By Save = By.id("com.android.contacts:id/editor_menu_save_button");
    By contactNameSaved = By.id("com.android.contacts:id/large_title");
    By nameAccion = By.name("ACEPTAR");



    public void saveContact() throws InterruptedException {
        String name = "Brad Pitt";
        Util.click(contactTab);
        Util.click(Add);
        Util.waitForEl(newContactScreen);
        Util.sendKeys(firstName, name);
        Thread.sleep(1000);
        Util.click(Save);
        Thread.sleep(1000);
        Util.waitForEl(contactNameSaved);
        Thread.sleep(1000);
        AppDriver.getDriver().navigate().back();
        Thread.sleep(1000);
    }
}
