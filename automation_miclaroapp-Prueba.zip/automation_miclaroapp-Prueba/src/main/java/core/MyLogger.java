package core;

import org.apache.log4j.Logger;


public class MyLogger {
    public static Logger log = Logger.getLogger(MyLogger.class);
}
