package core.constants;

public class Keyword {

    public enum CustomKeyword {

        FAILLOGINMESSAGE("El usuario y/o la contraseña son incorrectos"),

        FAILLOGINMESSAG("test 12356"),

        FAILLOGINMESSAGE2("test");


        public String value;

        CustomKeyword(String value) {

            this.value = value;
        }

    }


}