package core.constants;


public class Credentials {


}
