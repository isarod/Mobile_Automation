package core.managers;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ElementFetch{
    public WebElement getWebElement(AppiumDriver driver, String identifierType, WebElement identifierValue) {
        switch (identifierType) {
                case "id":
                    return driver.findElement(By.id(identifierType));
                case "class":
                    return driver.findElement(By.className(identifierType));
                case "xpath":
                case "text":
                return driver.findElement(By.xpath(identifierType));
        }
        return null;
    }
        public List getListWebelements(AppiumDriver driver, String identifierType, String identifierValue) {
            switch (identifierType) {
                case "id":
                case "class":
                case "xpath":
                case "text":
                    return driver.findElements(By.id(identifierValue));
                default:
                    return null;
            }
        }
    }
