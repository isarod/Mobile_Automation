package core.managers;

import core.MyLogger;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.net.MalformedURLException;

public class TestListener implements ITestListener {

    @Override
    public void onTestStart(ITestResult result) {
        AppiumServer.Start();

        String platform = result.getMethod().getXmlTest().getLocalParameters().get("platform");

        if(platform.contains("android"))
        {
            try {
                AppFactory.Android_LaunchApp();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        } else
        if(platform.contains("ios")){
            try {
                AppFactory.iOS_LaunchApp();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        MyLogger.log.info("Test Pass Success");
    }

    @Override
    public void onTestFailure(ITestResult result) {

    }

    @Override
    public void onTestSkipped(ITestResult result) {

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

    }

//    @Override
//    public void onTestFailedWithTimeout(ITestResult result) {
//
//    }

    @Override
    public void onStart(ITestContext context) {

    }

    @Override
    public void onFinish(ITestContext context) {
     /*  try {
           tearDown();
        } catch (InterruptedException e) {
           e.printStackTrace();
        }*/
    }

   public void tearDown() {
       AppDriver.getDriver().quit();
       AppiumServer.Stop();
    }
}
