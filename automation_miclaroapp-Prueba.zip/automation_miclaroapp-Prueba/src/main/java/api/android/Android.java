package api.android;

import io.appium.java_client.android.AndroidDriver;


public class Android {

/*
* Central host for referencing stuff
* */

    public static AndroidDriver driver;
  //  public static ADB adb;
  //  public static Apps app = new Apps();

}
